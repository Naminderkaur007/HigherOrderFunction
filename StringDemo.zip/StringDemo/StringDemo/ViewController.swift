


import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
       useOfFlatMap()
        
    }

    func useOfDrop()
    {
        //drop basically used to drop elements or object
        
        //drop break the loop when it gets false
        
        let strHelloWorld = "Hello World Atlas"
       
        let subStr = strHelloWorld.drop { (obj) -> Bool in
           if obj == "W" {
                return false
            }else{
                return true
            }
        }
        print("drop while with string = \(subStr)")
        //World Atlas
        
        
        let cast = ["Vivien", "Marlon", "Kim", "Karl"]
        let substring = cast.drop { (obj) -> Bool in
            if obj == "Kim" {
                           return false
                       }else{
                           return true
                       }
        }
        print("drop while with array of string = \(substring)")
        
        // Returns a subsequence containing all but the given number of initial elements.
        let dropFirst = strHelloWorld.dropFirst()
        print("dropFirst with string = \(dropFirst)")
        
        let dropFirstArray = cast.dropFirst()
        print("dropFirst with array string = \(dropFirstArray)")
        
        //dropFirst with parameter
        let dropFirstWithParameter = strHelloWorld.dropFirst(2)
        print("DropFirst parameter with string = \(dropFirstWithParameter)")
        
        let dropFirstWithParamArray = cast.dropFirst(3)
        print("DropFirst parameter with array string = \(dropFirstWithParamArray)")
        
        //Returns a subsequence containing all but the specified number of final elements.
        //it will not changed in itself means strHelloWorld will not update
        let dropLast = strHelloWorld.dropLast()
        print("dropLast with string = \(dropLast)")
        
        let dropLastArray = cast.dropLast()
        print("dropLast with array string = \(dropLastArray)")
        
        //dropLast with parameter
        let dropLastWithParameter = strHelloWorld.dropLast(5)
        print("DropLast parameter with string = \(dropLastWithParameter)")
        
        let dropLastWithParamArray = cast.dropLast(3)
        print("DropLast parameter with array string = \(dropLastWithParamArray)")
        
     
      
     
        var fullString = "Hello World Atlas"
        let popLastString = fullString.popLast()
        print("popLast Method Result = \(popLastString!)")
        //popLast will return s  the last element
        
        
        let removeLastString = fullString.removeLast()
        print("removeLast Method Result = \(removeLastString)")
        
        
        print("popLast with string = \(popLastString)")
        print("removeLastString with string = \(removeLastString)")

        
        var fullStrArray = ["Vivien", "Marlon", "Kim", "Karl"]
        let popLastObj = fullStrArray.popLast()
        print("full with string array = \(fullStrArray)")
        print("poplast with string array = \(popLastObj)")
        
    }
    
    func useOfFilter(){
        //as name ,as we like to filter our elements ,means we want some from all, according to condition
    
                
        let cast = ["Vivien", "Marlon", "Kim", "Karl"]
        
        let shortNames = cast.filter { (strObj) -> Bool in
            return strObj.count < 5
        }
        //it will return an array whose element are less than five
        print("use of filter = \(shortNames)")
      
        let helloStr = "Hello world"
        let abc = helloStr.filter { (obj) -> Bool in
            if obj == "a" || obj == "e" || obj == "i" || obj == "o" || obj == "u"{
                return false
            }else{
                return true
            }
        }
        //this will remove a,e,i,o,u
        print("use of filter = \(abc)")
        
    }

    func useOfMap(){
        //map is basically used ,to do same operation on  all elements
        
       
        let cast = ["Vivien", "Marlon", "Kim", "Karl", nil]
       
        let lowercaseNames = cast.map { (strObj) -> String in
            return (strObj?.lowercased() ?? "a")  //converting string objects into lowercase
        }
        
        let countTask = cast.map { (strObj) -> Int in
            return (strObj?.count ?? 0)  //counting the character in each object
        }
        
        let countTask2 = cast.map { (strObj) -> Bool in
            return (strObj?.count ?? 0 > 5)  //counting each object value returning the bool value 
        }
        
        print("lowercaseNames = \(lowercaseNames)")//lowercaseNames = ["vivien", "marlon", "kim", "karl", "a"]
        print("Count Task = \(countTask)")//countTask = [6, 6, 3, 4, 0]
        print("countTask2 = \(countTask2)")//countTask2 = [true, true, false, false, false]

        let letterCounts = cast.map { $0?.count }
        //dollar zero is a  parameter
        //compiler will automatically work for it
        
        print("letter counts = \(letterCounts)")
        //letter counts = [Optional(6), Optional(6), Optional(3), Optional(4), nil]

    }
    
    func useOfCompactMap(){
        
        //compact map is the advanced version of map ,compactMapped can remove nil value but map can't
        
        
    
        let possibleNumbers = ["1", "2", "three", "///4///", "5", nil]
       
      // ************************
        let mapped : [Int?] = possibleNumbers.map { (strObj) -> Int? in
            return Int(strObj ?? "a")
        }
        print("Mapped scenario 1 = \(mapped)")//This will return optional value and nil also
    // [Optional(1), Optional(2), nil, nil, Optional(5), nil]
        
        
        let compactMapped : [Int?] = possibleNumbers.compactMap { (strObj) -> Int? in
                   return (Int(strObj ?? "a"))
        }
        print("compact Mapped Scenario 1= \(compactMapped)")//it will return optional value and  remove nil value
        //[Optional(1), Optional(2), Optional(5)]
        
        
       //**********************************

        
        
    }
    
    func useOfFlatMap(){
   

    ///////////////////without optional return type ,same two times flatmap implemented
    let numbers1 = [[1], [2, 3, 4], [5, 6], [7, 8, 9, 10]]
    
    let mapped1 = numbers1.map { (obj) -> [Int] in
        return obj
    }
    let flatMapped1 = numbers1.flatMap { (obj) -> [Int] in
        return obj
    }
    let compactMapped1 = numbers1.compactMap { (obj) -> [Int] in
        return obj
    }
  
    
    /****************/
            print("Mapped1 = \(mapped1)")
            print("compact mapped1 = \(compactMapped1)")
            print("flatMapped1 = \(flatMapped1)")
    

    
}
    
    
    
    
}


